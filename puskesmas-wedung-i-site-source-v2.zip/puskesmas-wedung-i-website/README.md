# Puskesmas Wedung I — Website

Website profil dan pusat informasi pelayanan kesehatan Puskesmas Wedung I, Kabupaten Demak.

## Repository contents

- `site-source-v2.zip` — paket sumber situs HTML/CSS/JS beserta aset dan halaman CMS publik.
- `admin/config.yml` — konfigurasi Decap CMS (Decap Turbo + GitHub).
- `data/content.json` — konten yang dikelola CMS.
- `assets/uploads/` — media yang diunggah melalui CMS.
- `.github/workflows/deploy.yml` — workflow publikasi otomatis GitHub Pages.

## Deploy otomatis ke GitHub Pages

1. Buka **Settings → Pages** pada repository ini.
2. Pada **Build and deployment → Source**, pilih **GitHub Actions**.
3. Pastikan workflow **Deploy website to GitHub Pages** berhasil berjalan dari branch `main`.
4. Alamat project site GitHub Pages untuk repository ini adalah `https://iqbalyfarisy.github.io/puskesmas-wedung-1/` setelah Pages diaktifkan.

Setiap perubahan pada paket sumber, konfigurasi CMS, konten, atau media CMS di branch `main` akan menjalankan deployment otomatis.

## Mengaktifkan CMS

Dashboard CMS berada di `/admin/`. CMS menggunakan Decap Turbo dengan backend `turbo-github`. Sebelum login:

1. Buat organisasi di Decap Turbo, lalu hubungkan akun GitHub.
2. Install Decap Turbo GitHub App pada akun pemilik repository dan izinkan repository `iqbalyfarisy/puskesmas-wedung-1` saja jika memungkinkan.
3. Buat site baru di Decap Turbo dengan Git provider GitHub, repo `iqbalyfarisy/puskesmas-wedung-1`, branch `main`, config path `admin/config.yml`, dan admin interface URL `https://iqbalyfarisy.github.io/puskesmas-wedung-1/admin/`.
4. Salin Site ID dari halaman Overview, lalu ganti `GANTI_DENGAN_TURBO_SITE_ID` pada `admin/config.yml` dan commit perubahan.
5. Undang petugas yang berwenang melalui dashboard Decap Turbo. Uji draft, review, publish, dan unggah media sebelum dipakai.

Dokumentasi: https://decapcms.org/docs/turbo-getting-started/ dan https://decapcms.org/docs/turbo-connecting-a-site/.

## Sebelum website diumumkan ke publik

- Validasi nomor telepon, email, jam pelayanan, visi-misi, daftar layanan, struktur organisasi, statistik, serta dokumen yang akan dipublikasikan.
- Logo Puskesmas yang digunakan adalah konsep yang telah disetujui untuk pengembangan, belum dinyatakan sebagai logo resmi sebelum pengesahan instansi.
- Jangan mengunggah rekam medis, data pasien, NIK, nomor BPJS, atau informasi kesehatan pribadi.
- GitHub Pages tidak menerapkan file `_headers`; konfigurasi header keamanan memerlukan hosting atau lapisan proxy/CDN yang mendukung custom response headers.
- Jika domain resmi digunakan kelak, perbarui canonical URL, `og:url`, sitemap, robots.txt, dan admin URL Decap Turbo.
