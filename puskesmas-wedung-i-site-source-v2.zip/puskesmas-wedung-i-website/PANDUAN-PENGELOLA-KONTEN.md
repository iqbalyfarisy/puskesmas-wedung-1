# Panduan Pengelola Konten — Puskesmas Wedung I

Panduan ini ditujukan untuk petugas yang diberi akses sebagai pengelola website. CMS baru aktif setelah repositori GitHub, site Decap Turbo, Site ID, URL admin, dan hosting dikonfigurasi oleh administrator teknis.

## Masuk ke pengelola website

1. Buka `https://DOMAIN-RESMI/admin/`.
2. Masuk menggunakan akun yang diundang oleh administrator Decap Turbo.
3. Pilih menu **Publikasi Website** lalu buka **Berita, Pengumuman, Program, dan Edukasi**.
4. Konten tersimpan pada daftar di dalam satu berkas pengelolaan. Pilih bagian sesuai jenis konten yang ingin diperbarui.

## Jenis konten yang dapat dikelola

### Program dan Kegiatan

Isi judul, slug URL, kategori, tanggal, ringkasan, isi lengkap, foto (opsional), dan tautan sumber resmi (jika ada). Gunakan kategori dan tanggal sesuai dokumentasi yang telah diverifikasi.

### Pengumuman

Gunakan untuk pengumuman resmi, perubahan layanan, atau informasi publik yang telah disetujui. Cantumkan tanggal berlaku dengan jelas pada isi atau ringkasan.

### Berita

Gunakan untuk berita kegiatan dan kabar resmi Puskesmas. Tulis judul yang faktual, ringkasan yang informatif, isi lengkap, tanggal, dan foto dokumentasi yang layak dipublikasikan.

### Artikel dan Edukasi Kesehatan

Materi edukasi harus diperiksa oleh petugas atau tenaga kesehatan yang berwenang sebelum diterbitkan. Hindari klaim diagnosis, janji kesembuhan, atau anjuran pengobatan individual.

### Detail Pelayanan

Lengkapi nama layanan, kategori, ringkasan, deskripsi, persyaratan, jadwal, unit pelayanan, dan informasi tambahan. Jangan mengisi jam atau persyaratan berdasarkan perkiraan; konfirmasikan kepada penanggung jawab layanan.

## Menyimpan dan menerbitkan

1. Buat item baru atau buka item yang akan diperbarui.
2. Isi semua data yang sudah diverifikasi. Gunakan slug huruf kecil dan tanda hubung, misalnya `penyuluhan-kesehatan-lansia`.
3. Unggah foto yang sudah mendapat izin untuk dipublikasikan. Pastikan foto tidak memperlihatkan data pribadi pasien atau dokumen medis.
4. Aktifkan **Tampilkan di website** hanya setelah isi ditinjau dan disetujui.
5. Simpan sebagai draft atau kirim untuk review sesuai alur editorial yang diaktifkan administrator.
6. Setelah dipublikasikan, periksa halaman website untuk memastikan judul, tanggal, tautan, dan gambar tampil benar.

## Aturan privasi dan keamanan

- Jangan mengunggah rekam medis, hasil pemeriksaan pasien, NIK, nomor BPJS, nomor telepon pribadi, alamat rumah pasien, atau informasi kesehatan individu.
- Jangan menerbitkan foto pasien yang dapat dikenali tanpa persetujuan dan otorisasi yang sah dari pihak terkait.
- Jangan mengunggah kata sandi, token, atau data akses ke CMS.
- Jangan menampilkan nomor kontak darurat atau jadwal layanan sebelum diverifikasi oleh Puskesmas.
- Segera hubungi administrator jika akun petugas tidak lagi berwenang atau perangkat kerja hilang.

## Data yang perlu persetujuan sebelum dimasukkan

Jam dan jadwal pelayanan, persyaratan administrasi, daftar poli aktif, kapasitas rawat inap, jumlah SDM, visi dan misi resmi, struktur organisasi, statistik kinerja, nomor telepon, dan dokumen transparansi harus mendapat konfirmasi dari penanggung jawab masing-masing.
