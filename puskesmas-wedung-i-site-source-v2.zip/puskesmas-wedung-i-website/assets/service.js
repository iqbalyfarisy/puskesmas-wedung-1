(() => {
  const slug = new URLSearchParams(location.search).get('slug');
  const nameEl = document.querySelector('[data-service-name]');
  const summaryEl = document.querySelector('[data-service-summary]');
  const categoryEl = document.querySelector('[data-service-category]');
  const descEl = document.querySelector('[data-service-description]');
  const scheduleEl = document.querySelector('[data-service-schedule]');
  const unitEl = document.querySelector('[data-service-unit]');
  const reqEl = document.querySelector('[data-service-requirements]');
  const notesEl = document.querySelector('[data-service-notes]');
  const descriptionMeta = document.querySelector('meta[name="description"]');
  const ogTitle = document.querySelector('meta[property="og:title"]');
  const ogDescription = document.querySelector('meta[property="og:description"]');
  const twitterTitle = document.querySelector('meta[name="twitter:title"]');
  const twitterDescription = document.querySelector('meta[name="twitter:description"]');
  const fallback = 'Detail layanan belum tersedia atau belum dikonfirmasi oleh Puskesmas. Silakan kembali ke halaman Pelayanan untuk melihat informasi umum.';
  if (!slug || !/^[a-z0-9-]+$/.test(slug)) { descEl.textContent = fallback; return; }
  fetch('data/content.json', { cache: 'no-store' }).then(r => { if (!r.ok) throw new Error('Data layanan gagal dimuat'); return r.json(); }).then(data => {
    const item = (Array.isArray(data.services) ? data.services : []).find(x => x.slug === slug && x.published === true);
    if (!item) { descEl.textContent = fallback; return; }
    document.title = `${item.name} | Pelayanan Puskesmas Wedung I`;
    if (descriptionMeta) descriptionMeta.content = item.summary || 'Informasi pelayanan Puskesmas Wedung I Kabupaten Demak.';
    if (ogTitle) ogTitle.content = document.title;
    if (ogDescription) ogDescription.content = item.summary || '';
    if (twitterTitle) twitterTitle.content = document.title;
    if (twitterDescription) twitterDescription.content = item.summary || '';
    const structured = { '@context': 'https://schema.org', '@type': 'Service', name: item.name || 'Pelayanan Puskesmas Wedung I', description: item.summary || item.description || '', provider: { '@type': 'MedicalOrganization', name: 'Puskesmas Wedung I' } };
    let schema = document.querySelector('script[data-dynamic-schema]');
    if (!schema) { schema = document.createElement('script'); schema.type = 'application/ld+json'; schema.dataset.dynamicSchema = 'true'; document.head.append(schema); }
    schema.textContent = JSON.stringify(structured);
    nameEl.textContent = item.name || 'Detail Pelayanan';
    summaryEl.textContent = item.summary || '';
    categoryEl.textContent = item.category || 'Pelayanan kesehatan';
    descEl.textContent = item.description || item.summary || '';
    scheduleEl.textContent = item.schedule || '[Jadwal pelayanan akan diperbarui setelah dikonfirmasi.]';
    unitEl.textContent = item.unit || '[Unit pelayanan akan diperbarui.]';
    reqEl.replaceChildren();
    const reqs = Array.isArray(item.requirements) ? item.requirements.filter(Boolean) : [];
    (reqs.length ? reqs : ['[Persyaratan pelayanan akan diperbarui.]']).forEach(text => { const li = document.createElement('li'); li.textContent = text; reqEl.append(li); });
    notesEl.textContent = item.notes || 'Informasi ditampilkan sesuai data yang telah dikonfirmasi oleh Puskesmas.';
  }).catch(() => { descEl.textContent = fallback; });
})();
