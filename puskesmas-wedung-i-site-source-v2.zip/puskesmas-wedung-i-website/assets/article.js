(() => {
  const params = new URLSearchParams(window.location.search);
  const type = params.get('type');
  const slug = params.get('slug');
  const allowed = new Set(['programs', 'announcements', 'articles', 'education']);
  const titleEl = document.querySelector('[data-article-title]');
  const summaryEl = document.querySelector('[data-article-summary]');
  const bodyEl = document.querySelector('[data-article-body]');
  const sourceEl = document.querySelector('[data-article-source]');
  const descriptionMeta = document.querySelector('meta[name="description"]');
  const ogTitle = document.querySelector('meta[property="og:title"]');
  const ogDescription = document.querySelector('meta[property="og:description"]');
  const twitterTitle = document.querySelector('meta[name="twitter:title"]');
  const twitterDescription = document.querySelector('meta[name="twitter:description"]');
  const cleanUrl = (value) => {
    try { const u = new URL(value, window.location.href); return ['http:', 'https:'].includes(u.protocol) ? u.href : ''; }
    catch { return ''; }
  };
  const dateLabel = (value) => {
    if (!value) return '';
    const d = new Date(`${value}T00:00:00`);
    return Number.isNaN(d.valueOf()) ? value : new Intl.DateTimeFormat('id-ID', { dateStyle: 'long' }).format(d);
  };
  const showError = (message) => { if (bodyEl) bodyEl.textContent = message; };
  if (!allowed.has(type) || !slug) { showError('Publikasi tidak ditemukan. Periksa kembali tautan yang dibuka.'); return; }
  fetch('data/content.json', { cache: 'no-store' })
    .then((response) => { if (!response.ok) throw new Error('Konten tidak dapat dimuat.'); return response.json(); })
    .then((data) => {
      const item = (Array.isArray(data[type]) ? data[type] : []).find((entry) => entry.slug === slug && entry.published !== false);
      if (!item) { showError('Publikasi belum tersedia atau belum diterbitkan.'); return; }
      document.title = `${item.title} | Puskesmas Wedung I`;
      if (descriptionMeta) descriptionMeta.content = item.summary || 'Informasi dari Puskesmas Wedung I Kabupaten Demak.';
      if (ogTitle) ogTitle.content = document.title;
      if (ogDescription) ogDescription.content = item.summary || '';
      if (twitterTitle) twitterTitle.content = document.title;
      if (twitterDescription) twitterDescription.content = item.summary || '';
      const structured = { '@context': 'https://schema.org', '@type': 'Article', headline: item.title || 'Publikasi Puskesmas Wedung I', description: item.summary || '', datePublished: item.date || undefined, author: { '@type': 'Organization', name: 'Puskesmas Wedung I' }, publisher: { '@type': 'Organization', name: 'Puskesmas Wedung I' } };
      if (item.featured_image && /^\/?assets\/[a-zA-Z0-9_./-]+$/.test(item.featured_image) && !item.featured_image.includes('..')) structured.image = new URL(item.featured_image, window.location.href).href;
      let schema = document.querySelector('script[data-dynamic-schema]');
      if (!schema) { schema = document.createElement('script'); schema.type = 'application/ld+json'; schema.dataset.dynamicSchema = 'true'; document.head.append(schema); }
      schema.textContent = JSON.stringify(structured);
      titleEl.textContent = item.title || 'Publikasi Puskesmas';
      summaryEl.textContent = item.summary || '';
      bodyEl.replaceChildren();
      if (item.featured_image && /^\/?assets\/[a-zA-Z0-9_./-]+$/.test(item.featured_image) && !item.featured_image.includes('..')) {
        const img = document.createElement('img'); img.src = item.featured_image; img.alt = item.title || 'Foto publikasi'; img.loading = 'lazy'; img.decoding = 'async'; img.className = 'article-featured-image'; bodyEl.append(img);
      }
      const meta = document.createElement('p'); meta.className = 'article-meta';
      meta.textContent = [item.category, dateLabel(item.date)].filter(Boolean).join(' · '); bodyEl.append(meta);
      String(item.body || item.summary || '').split(/\n{2,}/).map(s => s.trim()).filter(Boolean).forEach((paragraph) => {
        const p = document.createElement('p'); p.textContent = paragraph; bodyEl.append(p);
      });
      const source = cleanUrl(item.source_url || '');
      if (source && sourceEl) {
        const a = document.createElement('a'); a.href = source; a.target = '_blank'; a.rel = 'noopener noreferrer'; a.className = 'text-link'; a.textContent = 'Buka sumber informasi ↗';
        sourceEl.hidden = false; sourceEl.replaceChildren(a);
      }
    })
    .catch(() => showError('Terjadi kendala saat memuat publikasi. Silakan coba kembali nanti.'));
})();
