document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.main-nav');
  const closeMenu = () => {
    if (!toggle || !nav) return;
    nav.classList.remove('is-open');
    toggle.setAttribute('aria-expanded', 'false');
    toggle.setAttribute('aria-label', 'Buka menu navigasi');
  };
  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      const open = nav.classList.toggle('is-open');
      toggle.setAttribute('aria-expanded', String(open));
      toggle.setAttribute('aria-label', open ? 'Tutup menu navigasi' : 'Buka menu navigasi');
    });
    nav.querySelectorAll('a').forEach((link) => link.addEventListener('click', closeMenu));
    document.addEventListener('keydown', (event) => { if (event.key === 'Escape') closeMenu(); });
    document.addEventListener('click', (event) => {
      if (nav.classList.contains('is-open') && !nav.contains(event.target) && !toggle.contains(event.target)) closeMenu();
    });
  }
  document.querySelectorAll('[data-year]').forEach((el) => { el.textContent = new Date().getFullYear(); });
  document.querySelectorAll('details').forEach((details) => details.addEventListener('toggle', () => {
    const summary = details.querySelector('summary'); if (summary) summary.setAttribute('aria-expanded', String(details.open));
  }));

  const dateLabel = (value) => {
    if (!value) return '';
    const date = new Date(`${value}T00:00:00`);
    return Number.isNaN(date.valueOf()) ? value : new Intl.DateTimeFormat('id-ID', { day: 'numeric', month: 'long', year: 'numeric' }).format(date);
  };
  const safeUrl = (value) => {
    if (!value) return '';
    try {
      const url = new URL(value, window.location.href);
      return ['http:', 'https:'].includes(url.protocol) ? url.href : '';
    } catch { return ''; }
  };
  const safeImage = (value) => /^\/?assets\/[a-zA-Z0-9_./-]+$/.test(value || '') && !value.includes('..') ? value : '';
  const create = (tag, className, text) => {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  };
  const renderProgramCards = (items, compact) => items.map((item, index) => {
    const article = create('article', compact ? 'story-card' : 'program-feature');
    const color = ['thumb-green', 'thumb-blue', 'thumb-mint', 'thumb-green'][index % 4];
    const artColor = ['art-green', 'art-blue', 'art-mint', 'art-gold'][index % 4];
    const imagePath = safeImage(item.featured_image);
    const visual = create('div', compact ? `story-thumb ${color}` : `program-feature-art ${artColor}`);
    if (imagePath) {
      const img = create('img'); img.src = imagePath; img.alt = item.title || 'Foto kegiatan'; img.loading = 'lazy'; img.decoding = 'async'; visual.append(img);
    } else {
      visual.append(create('span', '', item.category || 'PROGRAM KESEHATAN'));
    }
    const content = create('div', compact ? 'story-content' : 'program-feature-copy');
    content.append(create('span', 'story-date', [dateLabel(item.date), item.participant_count ? `${item.participant_count} peserta` : ''].filter(Boolean).join(' · ')));
    content.append(create('h3', '', item.title || 'Publikasi Puskesmas'));
    content.append(create('p', '', item.summary || 'Informasi kegiatan Puskesmas.'));
    const detail = create('a', 'text-link', 'Baca selengkapnya ↗');
    detail.href = `artikel.html?type=programs&slug=${encodeURIComponent(item.slug || '')}`;
    content.append(detail);
    article.append(visual, content);
    return article;
  });
  const renderAnnouncementCards = (items, type) => items.map((item, index) => {
    const card = create('article', `announcement-card ${index === 0 ? 'announcement-feature' : ''}`.trim());
    const label = create('span', `announcement-label ${index === 1 ? 'blue-label' : index === 2 ? 'gold-label' : ''}`.trim(), item.category || 'INFORMASI');
    card.append(label, create('h3', '', item.title || 'Informasi Puskesmas'), create('p', '', item.summary || ''), create('small', '', dateLabel(item.date)));
    const link = create('a', 'text-link', 'Baca selengkapnya ↗');
    link.href = `artikel.html?type=${encodeURIComponent(type)}&slug=${encodeURIComponent(item.slug || '')}`;
    card.append(link);
    return card;
  });
  const renderEducation = (items) => items.map((item) => {
    const row = create('a', 'info-placeholder');
    row.href = `artikel.html?type=education&slug=${encodeURIComponent(item.slug || '')}`;
    const icon = create('span', '', '＋');
    const copy = create('div'); copy.append(create('strong', '', item.title || 'Edukasi kesehatan'), create('small', '', item.category || 'Artikel edukasi'));
    row.append(icon, copy, create('b', '', '↗'));
    return row;
  });
  const renderServices = (items, compact) => items.map((item) => {
    const slug = String(item.slug || '').replace(/[^a-z0-9-]/g, '');
    const card = create(compact ? 'a' : 'article', compact ? 'service-card' : 'service-detail-card');
    if (compact) card.href = `layanan-detail.html?slug=${encodeURIComponent(slug)}`;
    else card.dataset.serviceSlug = slug;
    const icon = create('span', compact ? 'service-icon' : 'service-icon', '✚');
    card.append(icon);
    const title = create(compact ? 'strong' : 'h3', '', item.name || 'Pelayanan');
    const description = create('small', '', item.summary || item.description || 'Informasi layanan.');
    if (compact) { card.append(title, description, create('span', 'card-arrow', '↗')); }
    else {
      const copy = create('div'); copy.append(title, create('p', '', item.summary || item.description || ''), description);
      const more = create('a', 'text-link', 'Detail layanan ↗'); more.href = `layanan-detail.html?slug=${encodeURIComponent(slug)}`; copy.append(more);
      card.replaceChildren(icon, copy, create('span', 'status-pill', 'Informasi diperbarui'));
    }
    return card;
  });

  const renderEducationCards = (items) => items.map((item) => {
    const card = create('article', 'education-card');
    const icon = create('div', 'education-icon', '＋');
    const content = create('div');
    content.append(create('span', 'story-date', item.category || 'EDUKASI KESEHATAN'));
    content.append(create('h3', '', item.title || 'Edukasi Kesehatan'));
    content.append(create('p', '', item.summary || 'Informasi edukasi kesehatan.'));
    const link = create('a', 'text-link', 'Baca artikel ↗');
    link.href = `artikel.html?type=education&slug=${encodeURIComponent(item.slug || '')}`;
    content.append(link); card.append(icon, content); return card;
  });
  fetch('data/content.json', { cache: 'no-store' }).then((response) => {
    if (!response.ok) throw new Error('Konten CMS belum tersedia');
    return response.json();
  }).then((data) => {
    const published = (key) => Array.isArray(data[key]) ? data[key].filter((item) => item && item.published !== false).sort((a,b) => String(b.date || '').localeCompare(String(a.date || ''))) : [];
    const programs = published('programs');
    document.querySelectorAll('[data-cms-list="programs"]').forEach((target) => {
      if (programs.length) target.replaceChildren(...renderProgramCards(programs, target.classList.contains('story-grid')));
    });
    const announcements = published('announcements');
    document.querySelectorAll('[data-cms-list="announcements"]').forEach((target) => {
      if (announcements.length) target.replaceChildren(...renderAnnouncementCards(announcements, 'announcements'));
    });
    const articles = published('articles');
    document.querySelectorAll('[data-cms-list="articles"]').forEach((target) => {
      if (articles.length) target.replaceChildren(...renderAnnouncementCards(articles, 'articles'));
    });
    const services = published('services');
    document.querySelectorAll('[data-cms-list="services-home"]').forEach((target) => {
      if (services.length) target.replaceChildren(...renderServices(services, true));
    });
    document.querySelectorAll('[data-cms-list="services-detail"]').forEach((target) => {
      if (services.length) target.replaceChildren(...renderServices(services, false));
    });
    const education = published('education');
    document.querySelectorAll('[data-cms-list="education"]').forEach((target) => {
      if (education.length) target.replaceChildren(...renderEducation(education));
    });
    document.querySelectorAll('[data-cms-list="education-info"]').forEach((target) => {
      if (education.length) target.replaceChildren(...renderEducationCards(education));
    });
  }).catch(() => { /* Fallback content remains visible when CMS data is unavailable. */ });
});
